# FinCal — Android finance calculator

Native Android app (Kotlin + Jetpack Compose, Material 3) with six calculators.
Results update live as you type. Amounts are shown in Taka with lakh/crore grouping (৳ 12,34,567.89).

| # | Calculator | You enter | It finds |
|---|---|---|---|
| 1 | **Loan** | Loan amount, interest %, tenure | Monthly installment (EMI), total interest, year-wise repayment |
| 2 | **DPS** | Monthly deposit, interest %, tenure | Maturity amount, interest, year-wise growth |
| 3 | **FDR** | One-time deposit, interest %, tenure | Maturity amount |
| 4 | **Combo** | One-time deposit + monthly deposit, interest %, tenure | Maturity amount |
| 5 | **Mill-Bill** | One-time deposit (optional), monthly deposit, interest %, target maturity | Tenure needed to reach the target |
| 6 | **Savings Certificate** | Savings amount, profit %, tenure, payout type | Maturity amount (or monthly / quarterly profit) |

Extras on the deposit screens: compounding choice (Monthly / Quarterly / Half-yearly / Yearly / Simple)
and an optional **tax on interest %** (source tax), deducted each time interest is credited.
Tenure can be typed in years (decimals allowed, e.g. 2.5) or months.

## Formulas & assumptions

- **Loan EMI** — reducing balance: `EMI = P·r·(1+r)^n / ((1+r)^n − 1)`, `r = annual% / 12 / 100`, `n` = months.
- **DPS / FDR / Combo** — simulated month by month: deposit at the start of each month, interest accrues
  monthly on the balance (`annual% / 12`) and is added to the balance at each compounding interval.
  Defaults: DPS & Combo = monthly compounding, FDR = quarterly.
- **Mill-Bill** — same simulation, run until the balance first reaches the target; tenure is rounded
  up to the whole month.
- **Savings Certificate** — simple profit `P × rate × years` paid at maturity (or yearly-compounded,
  or paid out monthly / quarterly). Source tax % is deducted from the profit.

## Build the APK

### Option A — Android Studio (simplest)
1. Install Android Studio (Ladybug or newer).
2. *File → Open* → select this `FinCal` folder. Let Gradle sync (first sync downloads the SDK/libraries).
3. Plug in your phone (USB debugging on) and press **Run ▶**, or
   *Build → Build App Bundle(s) / APK(s) → Build APK(s)*.
   The APK appears in `app/build/outputs/apk/debug/app-debug.apk`.

If Studio suggests upgrading the Android Gradle Plugin, accepting is fine.

### Option B — GitHub (no install needed)
1. Create a GitHub repository and push this folder.
2. The included workflow `.github/workflows/build-apk.yml` runs the unit tests and builds the APKs.
3. Open the repo's **Actions** tab → latest run → download the **FinCal-apk** artifact.

### Command line
```bash
./gradlew testDebugUnitTest   # calculation tests
./gradlew assembleRelease     # app/build/outputs/apk/release/app-release.apk
```

The release build is signed with the debug key so it can be side-loaded immediately.
For Google Play, create your own keystore and update `signingConfig` in `app/build.gradle.kts`.

## Project layout

```
app/src/main/java/com/fincal/app/
├── MainActivity.kt              navigation host
├── calc/FinanceEngine.kt        all calculations (pure Kotlin, unit-tested)
├── util/Format.kt               Taka / lakh-crore formatting
└── ui/
    ├── theme/Theme.kt           colours, light & dark theme
    ├── components/Components.kt input fields, result card, tables
    └── screens/                 Home + the six calculator screens
app/src/test/.../FinanceEngineTest.kt
```

Minimum Android version: 8.0 (API 26).
