package com.fincal.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.fincal.app.ui.screens.Calculator
import com.fincal.app.ui.screens.CertificateScreen
import com.fincal.app.ui.screens.ComboScreen
import com.fincal.app.ui.screens.DpsScreen
import com.fincal.app.ui.screens.FdrScreen
import com.fincal.app.ui.screens.HomeScreen
import com.fincal.app.ui.screens.LoanScreen
import com.fincal.app.ui.screens.MillBillScreen
import com.fincal.app.ui.theme.FinCalTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FinCalTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    FinCalApp()
                }
            }
        }
    }
}

@Composable
fun FinCalApp() {
    val nav = rememberNavController()
    val back: () -> Unit = { nav.popBackStack() }
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { HomeScreen(onOpen = { nav.navigate(it.route) { launchSingleTop = true } }) }
        composable(Calculator.LOAN.route) { LoanScreen(back) }
        composable(Calculator.DPS.route) { DpsScreen(back) }
        composable(Calculator.FDR.route) { FdrScreen(back) }
        composable(Calculator.COMBO.route) { ComboScreen(back) }
        composable(Calculator.MILL_BILL.route) { MillBillScreen(back) }
        composable(Calculator.CERTIFICATE.route) { CertificateScreen(back) }
    }
}
