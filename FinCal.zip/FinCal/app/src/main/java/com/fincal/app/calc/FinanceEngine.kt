package com.fincal.app.calc

import kotlin.math.pow

/**
 * FinCal calculation engine — pure Kotlin, no Android dependencies, so it is unit-testable.
 *
 * Conventions
 *  - Rates are nominal annual percentages (e.g. 9.5 means 9.5% p.a.).
 *  - Monthly rate = annual / 12.
 *  - Recurring deposits are made at the START of each month (annuity-due, as banks run DPS).
 *  - Interest accrues monthly on the running balance and is credited (capitalised) at the
 *    end of each compounding period. With Compounding.NONE it is credited only at maturity.
 *  - Optional tax (source tax / AIT on interest) is deducted each time interest is credited.
 */

enum class Compounding(val label: String, val months: Int) {
    MONTHLY("Monthly", 1),
    QUARTERLY("Quarterly", 3),
    HALF_YEARLY("Half-yearly", 6),
    YEARLY("Yearly", 12),
    NONE("Simple", 0),
}

enum class CertificatePayout(val label: String) {
    AT_MATURITY("At maturity"),
    AT_MATURITY_COMPOUND("At maturity (compounded yearly)"),
    MONTHLY("Monthly profit"),
    QUARTERLY("Quarterly profit"),
}

// ---------- Result types ----------

data class LoanYearRow(
    val year: Int,
    val principalPaid: Double,
    val interestPaid: Double,
    val closingBalance: Double,
)

data class LoanResult(
    val emi: Double,
    val totalPayment: Double,
    val totalInterest: Double,
    val months: Int,
    val schedule: List<LoanYearRow>,
)

data class DepositYearRow(
    val year: Int,
    val totalDeposited: Double,
    val value: Double,
)

data class DepositResult(
    val maturity: Double,
    val totalDeposit: Double,
    val grossInterest: Double,
    val tax: Double,
    val netInterest: Double,
    val months: Int,
    val yearly: List<DepositYearRow>,
)

data class TenureResult(
    val months: Int,
    val maturity: Double,
    val totalDeposit: Double,
    val grossInterest: Double,
    val tax: Double,
    val netInterest: Double,
)

data class CertificateResult(
    val principal: Double,
    val grossProfit: Double,
    val tax: Double,
    val netProfit: Double,
    /** Net profit received each period (monthly/quarterly payout), null when paid at maturity. */
    val periodicNetProfit: Double?,
    val periods: Int,
    /** Principal + all net profit received over the tenure. */
    val totalReturn: Double,
    /** Lump sum received on the maturity date. */
    val amountOnMaturityDate: Double,
)

// ---------- Engine ----------

object FinanceEngine {

    /** Hard cap for the Mill-Bill tenure search: 100 years. */
    const val MAX_SEARCH_MONTHS = 1200

    /** 1. Loan — equated monthly installment with a year-wise amortisation summary. */
    fun loan(principal: Double, annualRatePct: Double, months: Int): LoanResult {
        require(principal > 0 && months > 0 && annualRatePct >= 0)
        val r = annualRatePct / 1200.0
        val emi = if (r == 0.0) {
            principal / months
        } else {
            val f = (1 + r).pow(months)
            principal * r * f / (f - 1)
        }

        val schedule = mutableListOf<LoanYearRow>()
        var balance = principal
        var yPrincipal = 0.0
        var yInterest = 0.0
        for (m in 1..months) {
            val interest = balance * r
            var principalPart = emi - interest
            if (m == months) principalPart = balance // absorb rounding drift
            balance -= principalPart
            yPrincipal += principalPart
            yInterest += interest
            if (m % 12 == 0 || m == months) {
                schedule += LoanYearRow(
                    year = (m + 11) / 12,
                    principalPaid = yPrincipal,
                    interestPaid = yInterest,
                    closingBalance = if (balance < 0.005) 0.0 else balance,
                )
                yPrincipal = 0.0
                yInterest = 0.0
            }
        }
        val total = emi * months
        return LoanResult(emi, total, total - principal, months, schedule)
    }

    /** 2. DPS — fixed monthly deposit. */
    fun dps(
        monthlyDeposit: Double,
        annualRatePct: Double,
        months: Int,
        compounding: Compounding = Compounding.MONTHLY,
        taxPct: Double = 0.0,
    ): DepositResult = deposit(0.0, monthlyDeposit, annualRatePct, months, compounding, taxPct)

    /** 3. FDR — one-time deposit. */
    fun fdr(
        deposit: Double,
        annualRatePct: Double,
        months: Int,
        compounding: Compounding = Compounding.QUARTERLY,
        taxPct: Double = 0.0,
    ): DepositResult = deposit(deposit, 0.0, annualRatePct, months, compounding, taxPct)

    /** 4. Combo — one-time deposit plus a monthly deposit. */
    fun combo(
        initialDeposit: Double,
        monthlyDeposit: Double,
        annualRatePct: Double,
        months: Int,
        compounding: Compounding = Compounding.MONTHLY,
        taxPct: Double = 0.0,
    ): DepositResult = deposit(initialDeposit, monthlyDeposit, annualRatePct, months, compounding, taxPct)

    /** Shared simulator behind DPS, FDR and Combo. */
    fun deposit(
        initialDeposit: Double,
        monthlyDeposit: Double,
        annualRatePct: Double,
        months: Int,
        compounding: Compounding,
        taxPct: Double = 0.0,
    ): DepositResult {
        require(months > 0 && annualRatePct >= 0 && initialDeposit >= 0 && monthlyDeposit >= 0)
        require(initialDeposit > 0 || monthlyDeposit > 0)
        val sim = DepositSim(initialDeposit, monthlyDeposit, annualRatePct, compounding, taxPct)
        val yearly = mutableListOf<DepositYearRow>()
        repeat(months) {
            sim.step()
            if (sim.month % 12 == 0 || sim.month == months) {
                yearly += DepositYearRow((sim.month + 11) / 12, sim.deposited, sim.closingValue())
            }
        }
        return sim.toResult(yearly)
    }

    /**
     * 5. Mill-Bill — how long until the deposit reaches the target maturity amount?
     * Returns null when the target can't be reached within [MAX_SEARCH_MONTHS].
     */
    fun millBill(
        initialDeposit: Double,
        monthlyDeposit: Double,
        annualRatePct: Double,
        targetMaturity: Double,
        compounding: Compounding = Compounding.MONTHLY,
        taxPct: Double = 0.0,
    ): TenureResult? {
        require(targetMaturity > 0 && annualRatePct >= 0 && initialDeposit >= 0 && monthlyDeposit >= 0)
        if (initialDeposit <= 0 && monthlyDeposit <= 0) return null
        val sim = DepositSim(initialDeposit, monthlyDeposit, annualRatePct, compounding, taxPct)
        while (sim.month < MAX_SEARCH_MONTHS) {
            sim.step()
            if (sim.closingValue() >= targetMaturity) {
                val r = sim.toResult(emptyList())
                return TenureResult(r.months, r.maturity, r.totalDeposit, r.grossInterest, r.tax, r.netInterest)
            }
        }
        return null
    }

    /** 6. Savings Certificate (Sanchayapatra-style) — simple profit, paid periodically or at maturity. */
    fun savingsCertificate(
        principal: Double,
        annualRatePct: Double,
        months: Int,
        payout: CertificatePayout = CertificatePayout.AT_MATURITY,
        taxPct: Double = 0.0,
    ): CertificateResult {
        require(principal > 0 && months > 0 && annualRatePct >= 0)
        val keep = 1 - taxPct / 100.0
        val years = months / 12.0
        val rate = annualRatePct / 100.0

        return when (payout) {
            CertificatePayout.AT_MATURITY, CertificatePayout.AT_MATURITY_COMPOUND -> {
                val gross = if (payout == CertificatePayout.AT_MATURITY) {
                    principal * rate * years
                } else {
                    principal * ((1 + rate).pow(years) - 1)
                }
                val net = gross * keep
                CertificateResult(
                    principal = principal,
                    grossProfit = gross,
                    tax = gross - net,
                    netProfit = net,
                    periodicNetProfit = null,
                    periods = 1,
                    totalReturn = principal + net,
                    amountOnMaturityDate = principal + net,
                )
            }
            CertificatePayout.MONTHLY, CertificatePayout.QUARTERLY -> {
                val periodMonths = if (payout == CertificatePayout.MONTHLY) 1 else 3
                val periods = months / periodMonths
                val perGross = principal * rate * periodMonths / 12.0
                val gross = perGross * periods
                val net = gross * keep
                val perNet = perGross * keep
                CertificateResult(
                    principal = principal,
                    grossProfit = gross,
                    tax = gross - net,
                    netProfit = net,
                    periodicNetProfit = perNet,
                    periods = periods,
                    totalReturn = principal + net,
                    amountOnMaturityDate = principal + if (periods > 0) perNet else 0.0,
                )
            }
        }
    }
}

/** Month-by-month deposit account simulator. */
private class DepositSim(
    initialDeposit: Double,
    private val monthlyDeposit: Double,
    annualRatePct: Double,
    private val compounding: Compounding,
    taxPct: Double,
) {
    private val r = annualRatePct / 1200.0
    private val keep = 1 - taxPct / 100.0

    var month = 0
        private set
    var deposited = initialDeposit
        private set
    private var balance = initialDeposit
    private var pending = 0.0        // accrued gross interest not yet credited
    private var creditedGross = 0.0  // gross interest already credited

    fun step() {
        balance += monthlyDeposit
        deposited += monthlyDeposit
        pending += balance * r
        month++
        if (compounding.months > 0 && month % compounding.months == 0) credit()
    }

    private fun credit() {
        creditedGross += pending
        balance += pending * keep
        pending = 0.0
    }

    /** What the account pays if closed now (pending interest credited, net of tax). */
    fun closingValue(): Double = balance + pending * keep

    fun toResult(yearly: List<DepositYearRow>): DepositResult {
        val gross = creditedGross + pending
        val maturity = closingValue()
        val net = maturity - deposited
        return DepositResult(
            maturity = maturity,
            totalDeposit = deposited,
            grossInterest = gross,
            tax = (gross - net).coerceAtLeast(0.0),
            netInterest = net,
            months = month,
            yearly = yearly,
        )
    }
}
