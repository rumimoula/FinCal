package com.fincal.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Emerald = Color(0xFF0B6E4F)
val EmeraldDark = Color(0xFF7FD8B4)
val Gold = Color(0xFFC9932E)

/** Accent colour per calculator, used for the home tiles and result cards. */
object Accent {
    val Loan = Color(0xFFB4442E)
    val Dps = Color(0xFF0B6E4F)
    val Fdr = Color(0xFF1F5FA8)
    val Combo = Color(0xFF6B4BA8)
    val MillBill = Color(0xFFC9932E)
    val Certificate = Color(0xFF2D7D8C)
}

private val LightColors = lightColorScheme(
    primary = Emerald,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDEFE0),
    onPrimaryContainer = Color(0xFF002116),
    secondary = Gold,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFCE8C3),
    onSecondaryContainer = Color(0xFF2A1800),
    background = Color(0xFFF6F8F7),
    surface = Color(0xFFF6F8F7),
    surfaceVariant = Color(0xFFE2E8E5),
    onSurfaceVariant = Color(0xFF424946),
    outline = Color(0xFF727976),
)

private val DarkColors = darkColorScheme(
    primary = EmeraldDark,
    onPrimary = Color(0xFF003827),
    primaryContainer = Color(0xFF005139),
    onPrimaryContainer = Color(0xFFCDEFE0),
    secondary = Color(0xFFF0C062),
    onSecondary = Color(0xFF452B00),
    secondaryContainer = Color(0xFF5E4100),
    onSecondaryContainer = Color(0xFFFCE8C3),
    background = Color(0xFF111413),
    surface = Color(0xFF111413),
    surfaceVariant = Color(0xFF3F4945),
    onSurfaceVariant = Color(0xFFBFC9C4),
    outline = Color(0xFF89938E),
)

private val AppTypography = Typography(
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
)

@Composable
fun FinCalTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
