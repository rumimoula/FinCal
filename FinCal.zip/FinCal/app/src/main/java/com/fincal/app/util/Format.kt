package com.fincal.app.util

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.abs

/** Bangladeshi number formatting: 12,34,567.89 grouping, Taka symbol, Lakh/Crore words. */
object Bdt {

    const val SYMBOL = "৳"

    /** 1234567.891 -> "12,34,567.89" */
    fun group(value: Double, decimals: Int = 2): String {
        val bd = BigDecimal(abs(value)).setScale(decimals, RoundingMode.HALF_UP)
        val plain = bd.toPlainString()
        val intPart = plain.substringBefore('.')
        val frac = if (decimals > 0) "." + plain.substringAfter('.', "") else ""
        val grouped = if (intPart.length <= 3) {
            intPart
        } else {
            val last3 = intPart.takeLast(3)
            val rest = intPart.dropLast(3)
            rest.reversed().chunked(2).joinToString(",").reversed() + "," + last3
        }
        val negative = value < 0 && bd.signum() != 0
        return (if (negative) "-" else "") + grouped + frac
    }

    /** "৳ 12,34,567.89" */
    fun money(value: Double, decimals: Int = 2): String = "$SYMBOL ${group(value, decimals)}"

    /** 1234567 -> "12.35 Lakh", 25000000 -> "2.50 Crore"; empty for small numbers. */
    fun words(value: Double): String {
        val a = abs(value)
        return when {
            a >= 1_00_00_000 -> "${group(a / 1_00_00_000, 2)} Crore"
            a >= 1_00_000 -> "${group(a / 1_00_000, 2)} Lakh"
            a >= 1_000 -> "${group(a / 1_000, 2)} Thousand"
            else -> ""
        }
    }

    fun percent(value: Double): String = group(value, 2).trimEnd('0').trimEnd('.') + "%"
}

/** 63 -> "5 years 3 months" */
fun formatTenure(months: Int): String {
    val y = months / 12
    val m = months % 12
    val parts = buildList {
        if (y > 0) add("$y year" + if (y > 1) "s" else "")
        if (m > 0) add("$m month" + if (m > 1) "s" else "")
    }
    return if (parts.isEmpty()) "0 months" else parts.joinToString(" ")
}
