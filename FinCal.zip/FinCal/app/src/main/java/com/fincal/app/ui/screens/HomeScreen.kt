@file:OptIn(ExperimentalMaterial3Api::class)

package com.fincal.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fincal.app.ui.theme.Accent

enum class Calculator(
    val route: String,
    val title: String,
    val badge: String,
    val tagline: String,
    val accent: Color,
) {
    LOAN("loan", "Loan", "EMI", "Find monthly installment", Accent.Loan),
    DPS("dps", "DPS", "DPS", "Monthly deposit → maturity", Accent.Dps),
    FDR("fdr", "FDR", "FDR", "Fixed deposit → maturity", Accent.Fdr),
    COMBO("combo", "Combo", "1+M", "Lump sum + monthly", Accent.Combo),
    MILL_BILL("millbill", "Mill-Bill", "MB", "Find time to reach a target", Accent.MillBill),
    CERTIFICATE("certificate", "Savings Certificate", "SC", "Sanchayapatra profit", Accent.Certificate),
}

@Composable
fun HomeScreen(onOpen: (Calculator) -> Unit) {
    Scaffold { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(Modifier.padding(top = 12.dp, bottom = 8.dp)) {
                    Text(
                        "FinCal",
                        style = MaterialTheme.typography.headlineSmall.copy(fontSize = 32.sp),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        "Loan, deposit and savings calculators",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            items(Calculator.entries) { calc -> CalculatorTile(calc) { onOpen(calc) } }
        }
    }
}

@Composable
private fun CalculatorTile(calc: Calculator, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = calc.accent.copy(alpha = 0.10f)),
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(calc.accent),
                contentAlignment = Alignment.Center,
            ) {
                Text(calc.badge, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(Modifier.height(14.dp))
            Text(calc.title, style = MaterialTheme.typography.titleMedium)
            Text(
                calc.tagline,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
