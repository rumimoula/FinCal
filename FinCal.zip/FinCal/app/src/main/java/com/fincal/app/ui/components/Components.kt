@file:OptIn(ExperimentalMaterial3Api::class)

package com.fincal.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.fincal.app.util.Bdt
import com.fincal.app.util.formatTenure
import kotlin.math.roundToInt

// ---------------- Input helpers ----------------

/** Keeps digits and a single decimal point (commas from pasted "1,00,000" are dropped). */
fun sanitizeNumber(input: String, maxDecimals: Int = 2): String {
    val sb = StringBuilder()
    var dot = false
    var decimals = 0
    for (c in input) {
        when {
            c.isDigit() && !dot -> sb.append(c)
            c.isDigit() && dot && decimals < maxDecimals -> { sb.append(c); decimals++ }
            c == '.' && !dot && maxDecimals > 0 -> { dot = true; sb.append(c) }
        }
    }
    return sb.toString().take(15)
}

/** Tenure text + unit -> whole months (1..1200), or null if invalid. */
fun tenureMonths(text: String, inYears: Boolean): Int? {
    val v = text.toDoubleOrNull() ?: return null
    val months = if (inYears) (v * 12).roundToInt() else v.roundToInt()
    return months.takeIf { it in 1..1200 }
}

fun String.toAmount(): Double? = toDoubleOrNull()?.takeIf { it >= 0 }
fun String.toRate(): Double? = toDoubleOrNull()?.takeIf { it in 0.0..100.0 }

// ---------------- Screen scaffold ----------------

@Composable
fun CalculatorScaffold(
    title: String,
    onBack: () -> Unit,
    onReset: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onReset) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Reset")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = {
                content()
                Spacer(Modifier.height(24.dp))
            },
        )
    }
}

// ---------------- Fields ----------------

@Composable
fun AmountField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    optional: Boolean = false,
    imeAction: ImeAction = ImeAction.Next,
) {
    val amount = value.toDoubleOrNull()
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(sanitizeNumber(it)) },
        label = { Text(if (optional) "$label (optional)" else label) },
        prefix = { Text("${Bdt.SYMBOL} ") },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = imeAction),
        supportingText = {
            if (amount != null && amount >= 1000) {
                Text("${Bdt.money(amount, 0)}  ·  ${Bdt.words(amount)}")
            }
        },
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
fun PercentField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    optional: Boolean = false,
    hint: String? = null,
) {
    val v = value.toDoubleOrNull()
    val error = v != null && v > 100
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(sanitizeNumber(it, maxDecimals = 3)) },
        label = { Text(if (optional) "$label (optional)" else label) },
        suffix = { Text("%") },
        singleLine = true,
        isError = error,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
        supportingText = {
            when {
                error -> Text("Must be 100% or less")
                hint != null -> Text(hint)
            }
        },
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
fun TenureField(
    value: String,
    inYears: Boolean,
    onValueChange: (String) -> Unit,
    onUnitChange: (Boolean) -> Unit,
) {
    val months = tenureMonths(value, inYears)
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = value,
            onValueChange = { onValueChange(sanitizeNumber(it, maxDecimals = if (inYears) 2 else 0)) },
            label = { Text("Tenure") },
            suffix = { Text(if (inYears) "years" else "months") },
            singleLine = true,
            isError = value.isNotEmpty() && months == null,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
            supportingText = {
                when {
                    value.isEmpty() -> {}
                    months == null -> Text("1 month to 100 years")
                    inYears -> Text(formatTenure(months) + " · $months months")
                    else -> Text(formatTenure(months))
                }
            },
            modifier = Modifier.weight(1f),
        )
        SingleChoiceSegmentedButtonRow(modifier = Modifier.padding(top = 8.dp)) {
            SegmentedButton(
                selected = inYears,
                onClick = { onUnitChange(true) },
                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
            ) { Text("Yr") }
            SegmentedButton(
                selected = !inYears,
                onClick = { onUnitChange(false) },
                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
            ) { Text("Mo") }
        }
    }
}

@Composable
fun <T> OptionChips(
    label: String,
    options: List<T>,
    selected: T,
    labelOf: (T) -> String,
    onSelect: (T) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            options.forEach { opt ->
                FilterChip(
                    selected = opt == selected,
                    onClick = { onSelect(opt) },
                    label = { Text(labelOf(opt)) },
                )
            }
        }
    }
}

// ---------------- Results ----------------

@Composable
fun ResultCard(
    accent: Color,
    headline: String,
    value: String,
    subValue: String? = null,
    rows: List<Pair<String, String>>,
    extra: (@Composable () -> Unit)? = null,
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(accent)
                .padding(horizontal = 20.dp, vertical = 18.dp),
        ) {
            Text(headline, color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.labelLarge)
            Text(
                value,
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
            )
            if (subValue != null) {
                Text(subValue, color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyMedium)
            }
        }
        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
            rows.forEachIndexed { i, (k, v) ->
                if (i > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(k, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(v, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
                }
            }
            if (extra != null) {
                Spacer(Modifier.height(8.dp))
                extra()
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

/** Two-part proportion bar, e.g. principal vs interest. */
@Composable
fun SplitBar(first: Double, second: Double, firstLabel: String, secondLabel: String, accent: Color) {
    val total = first + second
    if (total <= 0) return
    val secondColor = MaterialTheme.colorScheme.secondary
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp)),
        ) {
            if (first > 0) Box(Modifier.weight(first.toFloat()).fillMaxHeight().background(accent))
            if (second > 0) Box(Modifier.weight(second.toFloat()).fillMaxHeight().background(secondColor))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Legend(accent, "$firstLabel ${Bdt.percent(first / total * 100)}")
            Legend(secondColor, "$secondLabel ${Bdt.percent(second / total * 100)}")
        }
    }
}

@Composable
private fun Legend(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(text, style = MaterialTheme.typography.labelMedium)
    }
}

/** Collapsible year-wise table. First column is narrow, the rest share the width. */
@Composable
fun YearTable(title: String, headers: List<String>, rows: List<List<String>>) {
    if (rows.isEmpty()) return
    var open by rememberSaveable { mutableStateOf(false) }
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { open = !open }) { Text(if (open) "Hide" else "Show") }
        }
        AnimatedVisibility(visible = open) {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                TableRow(headers, header = true)
                rows.forEach {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    TableRow(it, header = false)
                }
            }
        }
    }
}

@Composable
private fun TableRow(cells: List<String>, header: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        cells.forEachIndexed { i, cell ->
            Text(
                cell,
                modifier = Modifier.weight(if (i == 0) 0.6f else 1.2f),
                textAlign = if (i == 0) TextAlign.Start else TextAlign.End,
                style = if (header) MaterialTheme.typography.labelMedium else MaterialTheme.typography.bodySmall,
                fontWeight = if (header) FontWeight.SemiBold else FontWeight.Normal,
                color = if (header) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

@Composable
fun EmptyHint(text: String) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(text, Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun Note(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 4.dp),
    )
}
