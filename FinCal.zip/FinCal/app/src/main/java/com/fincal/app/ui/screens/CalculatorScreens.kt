package com.fincal.app.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.fincal.app.calc.CertificatePayout
import com.fincal.app.calc.Compounding
import com.fincal.app.calc.DepositResult
import com.fincal.app.calc.FinanceEngine
import com.fincal.app.ui.components.AmountField
import com.fincal.app.ui.components.CalculatorScaffold
import com.fincal.app.ui.components.EmptyHint
import com.fincal.app.ui.components.Note
import com.fincal.app.ui.components.OptionChips
import com.fincal.app.ui.components.PercentField
import com.fincal.app.ui.components.ResultCard
import com.fincal.app.ui.components.SplitBar
import com.fincal.app.ui.components.TenureField
import com.fincal.app.ui.components.YearTable
import com.fincal.app.ui.components.tenureMonths
import com.fincal.app.ui.components.toAmount
import com.fincal.app.ui.components.toRate
import com.fincal.app.util.Bdt
import com.fincal.app.util.formatTenure

private const val TAX_HINT = "Source tax deducted when interest is credited"

// =====================================================================
// 1. Loan
// =====================================================================

@Composable
fun LoanScreen(onBack: () -> Unit) {
    val calc = Calculator.LOAN
    var amount by rememberSaveable { mutableStateOf("") }
    var rate by rememberSaveable { mutableStateOf("") }
    var tenure by rememberSaveable { mutableStateOf("") }
    var inYears by rememberSaveable { mutableStateOf(true) }

    val p = amount.toAmount()
    val r = rate.toRate()
    val n = tenureMonths(tenure, inYears)
    val result = remember(p, r, n) {
        if (p != null && p > 0 && r != null && n != null) FinanceEngine.loan(p, r, n) else null
    }

    CalculatorScaffold(
        title = "Loan EMI",
        onBack = onBack,
        onReset = { amount = ""; rate = ""; tenure = ""; inYears = true },
    ) {
        AmountField("Loan amount", amount, { amount = it })
        PercentField("Interest rate (p.a.)", rate, { rate = it })
        TenureField(tenure, inYears, { tenure = it }, { inYears = it })

        if (result == null) {
            EmptyHint("Enter loan amount, interest rate and tenure to see the monthly installment.")
        } else {
            val principal = result.totalPayment - result.totalInterest
            ResultCard(
                accent = calc.accent,
                headline = "Monthly installment (EMI)",
                value = Bdt.money(result.emi),
                subValue = "${result.months} installments",
                rows = listOf(
                    "Loan amount" to Bdt.money(principal),
                    "Total interest" to Bdt.money(result.totalInterest),
                    "Total payment" to Bdt.money(result.totalPayment),
                ),
                extra = { SplitBar(principal, result.totalInterest, "Principal", "Interest", calc.accent) },
            )
            YearTable(
                title = "Year-wise repayment",
                headers = listOf("Year", "Principal", "Interest", "Balance"),
                rows = result.schedule.map {
                    listOf(
                        "${it.year}",
                        Bdt.group(it.principalPaid, 0),
                        Bdt.group(it.interestPaid, 0),
                        Bdt.group(it.closingBalance, 0),
                    )
                },
            )
        }
        Note("Reducing-balance method: interest is charged monthly on the outstanding principal (annual rate ÷ 12).")
    }
}

// =====================================================================
// 2–4. DPS, FDR, Combo (shared screen)
// =====================================================================

@Composable
fun DpsScreen(onBack: () -> Unit) = DepositScreen(
    calc = Calculator.DPS, title = "DPS",
    hasLumpSum = false, hasMonthly = true, defaultCompounding = Compounding.MONTHLY, onBack = onBack,
)

@Composable
fun FdrScreen(onBack: () -> Unit) = DepositScreen(
    calc = Calculator.FDR, title = "FDR",
    hasLumpSum = true, hasMonthly = false, defaultCompounding = Compounding.QUARTERLY, onBack = onBack,
)

@Composable
fun ComboScreen(onBack: () -> Unit) = DepositScreen(
    calc = Calculator.COMBO, title = "Combo (Lump sum + Monthly)",
    hasLumpSum = true, hasMonthly = true, defaultCompounding = Compounding.MONTHLY, onBack = onBack,
)

@Composable
private fun DepositScreen(
    calc: Calculator,
    title: String,
    hasLumpSum: Boolean,
    hasMonthly: Boolean,
    defaultCompounding: Compounding,
    onBack: () -> Unit,
) {
    var lump by rememberSaveable { mutableStateOf("") }
    var monthly by rememberSaveable { mutableStateOf("") }
    var rate by rememberSaveable { mutableStateOf("") }
    var tenure by rememberSaveable { mutableStateOf("") }
    var inYears by rememberSaveable { mutableStateOf(true) }
    var compounding by rememberSaveable { mutableStateOf(defaultCompounding) }
    var tax by rememberSaveable { mutableStateOf("") }

    val l = if (hasLumpSum) lump.toAmount() else 0.0
    val m = if (hasMonthly) monthly.toAmount() else 0.0
    val r = rate.toRate()
    val n = tenureMonths(tenure, inYears)
    val t = if (tax.isBlank()) 0.0 else tax.toRate()

    val result = remember(l, m, r, n, compounding, t) {
        if (l != null && m != null && r != null && n != null && t != null && (l > 0 || m > 0) &&
            (!hasLumpSum || l > 0) && (!hasMonthly || m > 0)
        ) {
            FinanceEngine.deposit(l, m, r, n, compounding, t)
        } else {
            null
        }
    }

    CalculatorScaffold(
        title = title,
        onBack = onBack,
        onReset = {
            lump = ""; monthly = ""; rate = ""; tenure = ""; inYears = true
            compounding = defaultCompounding; tax = ""
        },
    ) {
        if (hasLumpSum) AmountField(if (hasMonthly) "One-time deposit" else "Deposit amount", lump, { lump = it })
        if (hasMonthly) AmountField("Monthly deposit", monthly, { monthly = it })
        PercentField("Interest rate (p.a.)", rate, { rate = it })
        TenureField(tenure, inYears, { tenure = it }, { inYears = it })
        OptionChips("Interest compounding", Compounding.entries, compounding, { it.label }) { compounding = it }
        PercentField("Tax on interest", tax, { tax = it }, optional = true, hint = TAX_HINT)

        if (result == null) {
            EmptyHint("Fill in the deposit, interest rate and tenure to see the maturity amount.")
        } else {
            DepositResultSection(result, calc)
        }
        Note(
            if (hasMonthly) {
                "Monthly deposits are assumed at the start of each month. Interest accrues monthly and is " +
                    "added to the balance at each compounding interval."
            } else {
                "Interest accrues monthly and is added to the balance at each compounding interval " +
                    "(banks usually compound FDRs quarterly or at each renewal)."
            },
        )
    }
}

@Composable
private fun DepositResultSection(result: DepositResult, calc: Calculator) {
    val rows = buildList {
        add("Total deposit" to Bdt.money(result.totalDeposit))
        if (result.tax > 0.005) {
            add("Interest (gross)" to Bdt.money(result.grossInterest))
            add("Tax deducted" to "− " + Bdt.money(result.tax))
            add("Interest (net)" to Bdt.money(result.netInterest))
        } else {
            add("Interest earned" to Bdt.money(result.netInterest))
        }
        add("Tenure" to formatTenure(result.months))
    }
    ResultCard(
        accent = calc.accent,
        headline = "Maturity amount",
        value = Bdt.money(result.maturity),
        subValue = Bdt.words(result.maturity).ifEmpty { null },
        rows = rows,
        extra = { SplitBar(result.totalDeposit, result.netInterest, "Deposit", "Interest", calc.accent) },
    )
    YearTable(
        title = "Year-wise growth",
        headers = listOf("Year", "Deposited", "Value"),
        rows = result.yearly.map {
            listOf("${it.year}", Bdt.group(it.totalDeposited, 0), Bdt.group(it.value, 0))
        },
    )
}

// =====================================================================
// 5. Mill-Bill — find tenure
// =====================================================================

@Composable
fun MillBillScreen(onBack: () -> Unit) {
    val calc = Calculator.MILL_BILL
    var lump by rememberSaveable { mutableStateOf("") }
    var monthly by rememberSaveable { mutableStateOf("") }
    var rate by rememberSaveable { mutableStateOf("") }
    var target by rememberSaveable { mutableStateOf("") }
    var compounding by rememberSaveable { mutableStateOf(Compounding.MONTHLY) }
    var tax by rememberSaveable { mutableStateOf("") }

    val l = if (lump.isBlank()) 0.0 else lump.toAmount()
    val m = monthly.toAmount()
    val r = rate.toRate()
    val goal = target.toAmount()
    val t = if (tax.isBlank()) 0.0 else tax.toRate()
    val inputsOk = l != null && m != null && r != null && goal != null && goal > 0 && t != null && (l > 0 || m > 0)

    val result = remember(l, m, r, goal, compounding, t) {
        if (inputsOk) FinanceEngine.millBill(l!!, m!!, r!!, goal!!, compounding, t!!) else null
    }

    CalculatorScaffold(
        title = "Mill-Bill",
        onBack = onBack,
        onReset = { lump = ""; monthly = ""; rate = ""; target = ""; compounding = Compounding.MONTHLY; tax = "" },
    ) {
        AmountField("One-time deposit", lump, { lump = it }, optional = true)
        AmountField("Monthly deposit", monthly, { monthly = it })
        PercentField("Interest rate (p.a.)", rate, { rate = it })
        AmountField("Target maturity amount", target, { target = it })
        OptionChips("Interest compounding", Compounding.entries, compounding, { it.label }) { compounding = it }
        PercentField("Tax on interest", tax, { tax = it }, optional = true, hint = TAX_HINT)

        when {
            !inputsOk -> EmptyHint("Enter the monthly deposit, interest rate and your target amount to find how long it takes.")
            result == null -> EmptyHint("This target can't be reached within 100 years with these inputs. Try a higher deposit or rate.")
            else -> {
                ResultCard(
                    accent = calc.accent,
                    headline = "Time needed to reach the target",
                    value = formatTenure(result.months),
                    subValue = "${result.months} months",
                    rows = buildList {
                        add("Target amount" to Bdt.money(goal!!))
                        add("Maturity at that point" to Bdt.money(result.maturity))
                        add("Total deposit" to Bdt.money(result.totalDeposit))
                        if (result.tax > 0.005) add("Tax deducted" to "− " + Bdt.money(result.tax))
                        add("Interest (net)" to Bdt.money(result.netInterest))
                    },
                    extra = { SplitBar(result.totalDeposit, result.netInterest, "Deposit", "Interest", calc.accent) },
                )
            }
        }
        Note("Tenure is rounded up to the first whole month in which the balance reaches the target.")
    }
}

// =====================================================================
// 6. Savings Certificate
// =====================================================================

@Composable
fun CertificateScreen(onBack: () -> Unit) {
    val calc = Calculator.CERTIFICATE
    var amount by rememberSaveable { mutableStateOf("") }
    var rate by rememberSaveable { mutableStateOf("") }
    var tenure by rememberSaveable { mutableStateOf("") }
    var inYears by rememberSaveable { mutableStateOf(true) }
    var payout by rememberSaveable { mutableStateOf(CertificatePayout.AT_MATURITY) }
    var tax by rememberSaveable { mutableStateOf("") }

    val p = amount.toAmount()
    val r = rate.toRate()
    val n = tenureMonths(tenure, inYears)
    val t = if (tax.isBlank()) 0.0 else tax.toRate()
    val result = remember(p, r, n, payout, t) {
        if (p != null && p > 0 && r != null && n != null && t != null) {
            FinanceEngine.savingsCertificate(p, r, n, payout, t)
        } else {
            null
        }
    }

    CalculatorScaffold(
        title = "Savings Certificate",
        onBack = onBack,
        onReset = { amount = ""; rate = ""; tenure = ""; inYears = true; payout = CertificatePayout.AT_MATURITY; tax = "" },
    ) {
        AmountField("Savings amount", amount, { amount = it })
        PercentField("Profit rate (p.a.)", rate, { rate = it })
        TenureField(tenure, inYears, { tenure = it }, { inYears = it })
        OptionChips("Profit payment", CertificatePayout.entries, payout, { it.label }) { payout = it }
        PercentField("Source tax on profit", tax, { tax = it }, optional = true, hint = "Deducted from each profit payment")

        if (result == null) {
            EmptyHint("Enter the savings amount, profit rate and tenure to see the maturity amount.")
        } else {
            val periodic = result.periodicNetProfit
            if (periodic == null) {
                ResultCard(
                    accent = calc.accent,
                    headline = "Maturity amount",
                    value = Bdt.money(result.totalReturn),
                    subValue = Bdt.words(result.totalReturn).ifEmpty { null },
                    rows = buildList {
                        add("Savings amount" to Bdt.money(result.principal))
                        if (result.tax > 0.005) {
                            add("Profit (gross)" to Bdt.money(result.grossProfit))
                            add("Source tax" to "− " + Bdt.money(result.tax))
                        }
                        add("Profit (net)" to Bdt.money(result.netProfit))
                    },
                    extra = { SplitBar(result.principal, result.netProfit, "Principal", "Profit", calc.accent) },
                )
            } else {
                val per = if (payout == CertificatePayout.MONTHLY) "Monthly" else "Quarterly"
                ResultCard(
                    accent = calc.accent,
                    headline = "$per profit (net)",
                    value = Bdt.money(periodic),
                    subValue = "${result.periods} payments",
                    rows = buildList {
                        add("Savings amount" to Bdt.money(result.principal))
                        if (result.tax > 0.005) add("Source tax (total)" to "− " + Bdt.money(result.tax))
                        add("Total profit (net)" to Bdt.money(result.netProfit))
                        add("Paid on maturity date" to Bdt.money(result.amountOnMaturityDate))
                        add("Total return" to Bdt.money(result.totalReturn))
                    },
                    extra = { SplitBar(result.principal, result.netProfit, "Principal", "Profit", calc.accent) },
                )
            }
        }
        Note(
            "Profit is simple (not reinvested) unless 'compounded yearly' is chosen. Government savings " +
                "certificates may use slab-based rates and tax — enter the rate and tax that apply to you.",
        )
    }
}
