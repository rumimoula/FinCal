package com.fincal.app

import com.fincal.app.calc.CertificatePayout
import com.fincal.app.calc.Compounding
import com.fincal.app.calc.FinanceEngine
import com.fincal.app.util.Bdt
import com.fincal.app.util.formatTenure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import kotlin.math.pow

class FinanceEngineTest {

    private val eps = 0.01

    @Test fun loanEmi() {
        val r = FinanceEngine.loan(1_000_000.0, 9.0, 60)
        assertEquals(20_758.36, r.emi, eps)
        assertEquals(0.0, r.schedule.last().closingBalance, eps)
        assertEquals(1_000_000.0, r.schedule.sumOf { it.principalPaid }, eps)
        assertEquals(r.totalInterest, r.schedule.sumOf { it.interestPaid }, 0.05)
    }

    @Test fun loanZeroRate() {
        assertEquals(1_000.0, FinanceEngine.loan(12_000.0, 0.0, 12).emi, eps)
    }

    @Test fun dpsMonthlyMatchesAnnuityDue() {
        val r = FinanceEngine.dps(1_000.0, 12.0, 12, Compounding.MONTHLY)
        val expected = 1_000.0 * ((1.01.pow(12) - 1) / 0.01) * 1.01
        assertEquals(expected, r.maturity, eps)
        assertEquals(12_000.0, r.totalDeposit, eps)
    }

    @Test fun fdrQuarterly() {
        val r = FinanceEngine.fdr(100_000.0, 8.0, 12, Compounding.QUARTERLY)
        assertEquals(100_000.0 * 1.02.pow(4), r.maturity, eps)
    }

    @Test fun fdrSimpleWithTax() {
        val r = FinanceEngine.fdr(100_000.0, 10.0, 12, Compounding.NONE, taxPct = 10.0)
        assertEquals(10_000.0, r.grossInterest, eps)
        assertEquals(1_000.0, r.tax, eps)
        assertEquals(109_000.0, r.maturity, eps)
    }

    @Test fun comboIsSumOfParts() {
        val combo = FinanceEngine.combo(50_000.0, 2_000.0, 9.0, 36, Compounding.QUARTERLY)
        val fdr = FinanceEngine.fdr(50_000.0, 9.0, 36, Compounding.QUARTERLY)
        val dps = FinanceEngine.dps(2_000.0, 9.0, 36, Compounding.QUARTERLY)
        assertEquals(fdr.maturity + dps.maturity, combo.maturity, eps)
    }

    @Test fun millBillFindsTenure() {
        val target = FinanceEngine.dps(1_000.0, 12.0, 12).maturity
        val t = FinanceEngine.millBill(0.0, 1_000.0, 12.0, target)!!
        assertEquals(12, t.months)
        assertNull(FinanceEngine.millBill(0.0, 0.0, 10.0, 1_000.0))
    }

    @Test fun savingsCertificate() {
        val m = FinanceEngine.savingsCertificate(500_000.0, 11.0, 60, CertificatePayout.AT_MATURITY, 10.0)
        assertEquals(275_000.0, m.grossProfit, eps)
        assertEquals(747_500.0, m.totalReturn, eps)
        val q = FinanceEngine.savingsCertificate(100_000.0, 12.0, 36, CertificatePayout.QUARTERLY)
        assertEquals(3_000.0, q.periodicNetProfit!!, eps)
        assertEquals(12, q.periods)
    }

    @Test fun formatting() {
        assertEquals("12,34,567.89", Bdt.group(1_234_567.891))
        assertEquals("999", Bdt.group(999.0, 0))
        assertEquals("1,00,00,000", Bdt.group(10_000_000.0, 0))
        assertEquals("12.35 Lakh", Bdt.words(1_234_567.0))
        assertEquals("5 years 3 months", formatTenure(63))
    }
}
